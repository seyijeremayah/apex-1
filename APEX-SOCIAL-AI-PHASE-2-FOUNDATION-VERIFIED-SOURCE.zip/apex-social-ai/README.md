# APEX SOCIAL AI

A multi-tenant AI social media operations platform. This repository is the **Phase 2 application foundation**, not a production-ready social publisher.

## Approved product constraints

- Next.js 16 App Router, TypeScript, Tailwind CSS and shadcn/ui conventions.
- Supabase for Auth, PostgreSQL and Storage; Vercel as the deployment target.
- BYOK: each company supplies its own AI/provider credentials.
- Social integration order: Instagram, Facebook, TikTok.
- Human approval is mandatory before any public publishing action.
- One centralized SaaS platform with isolated company workspaces.
- No payment processing in the approved initial scope.

## Requirements

- Node.js 20.9 or newer (Node 22 LTS recommended).
- npm 10 or a compatible package manager.
- A Supabase project is not required to inspect the demo shell, but is required for authentication/session functionality.

## Local setup

1. Copy `.env.example` to `.env.local`.
2. Set `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY` from the Supabase project.
3. Install pinned dependencies with `npm install`.
4. Start the app with `npm run dev`.
5. Open `http://localhost:3000`.

The dashboard currently uses clearly labelled sample/demo data. Social channels are not connected and no public publishing is possible from this foundation.

## Current implementation status

### Implemented in this foundation

- Next.js App Router project structure and TypeScript strict mode.
- Dark APEX workspace shell and responsive dashboard UI.
- Placeholder routes for content, calendar, approvals, integrations, analytics and settings.
- Supabase browser/server client factories using `@supabase/ssr`.
- Next.js 16 `proxy.ts` session refresh boundary using verified claims.
- Auth callback route with safe local redirect handling.
- Initial social provider interfaces and approval-binding domain types.
- Environment example and security-focused project documentation.

### Not implemented yet

- Production authentication screens, onboarding, workspace creation or membership management.
- Database migrations, final schema, RLS policies or Storage policies.
- Credential encryption/KMS, OAuth connection flows or provider app registrations.
- AI model adapters, content generation, publishing workers, scheduling or analytics ingestion.
- Live integrations, public publishing, billing or production deployment.

## Security notes

- Never place Supabase `service_role`/secret keys or customer provider credentials in `NEXT_PUBLIC_*` variables.
- The app does not yet expose authenticated customer data routes. Before adding them, verify identity with `supabase.auth.getClaims()` and resolve organization membership server-side.
- RLS and database grants must be implemented and tested for every exposed tenant-owned table before customer data is stored.
- No provider adapter in this foundation can publish. A future publishing worker must verify the immutable approval binding and idempotency key immediately before the external side effect.

## Commands

- `npm run dev` — local development
- `npm run lint` — ESLint
- `npm run typecheck` — TypeScript check
- `npm run build` — production build

## Governance

This work is local and reviewable. It has not been pushed to GitHub, connected to a live Supabase project, or deployed to Vercel. Those actions require separate authorization.
