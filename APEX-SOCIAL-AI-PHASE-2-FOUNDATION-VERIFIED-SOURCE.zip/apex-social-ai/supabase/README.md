# Supabase project workspace

No migrations are included in this foundation. The final multi-tenant schema, role matrix, grants, RLS policies and Storage policies must be designed and security-reviewed before the first customer-data migration is added.
