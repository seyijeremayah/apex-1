export type ApprovalStatus = "pending" | "approved" | "changes_requested" | "revoked" | "expired";

/** Approval is bound to immutable content/media/platform targets, not a mutable draft. */
export interface ApprovalBinding {
  organizationId: string;
  contentVersionId: string;
  contentSha256: string;
  mediaManifestSha256: string;
  platform: "instagram" | "facebook" | "tiktok";
  socialAccountId: string;
  action: "publish";
  scheduledFor: string;
}

export interface ApprovalRecord extends ApprovalBinding {
  id: string;
  status: ApprovalStatus;
  approverUserId: string | null;
  approvedAt: string | null;
  revokedAt: string | null;
}

export function approvalMatchesCurrentVersion(
  approval: ApprovalRecord,
  current: ApprovalBinding,
): boolean {
  return approval.status === "approved" &&
    approval.organizationId === current.organizationId &&
    approval.contentVersionId === current.contentVersionId &&
    approval.contentSha256 === current.contentSha256 &&
    approval.mediaManifestSha256 === current.mediaManifestSha256 &&
    approval.platform === current.platform &&
    approval.socialAccountId === current.socialAccountId &&
    approval.action === current.action &&
    approval.scheduledFor === current.scheduledFor &&
    Boolean(approval.approverUserId && approval.approvedAt);
}
