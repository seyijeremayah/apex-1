export type SocialPlatform = "instagram" | "facebook" | "tiktok";

export type ProviderCapability =
  | "publish_text"
  | "publish_image"
  | "publish_video"
  | "read_insights"
  | "read_comments"
  | "reply_comments";

export type ProviderConnectionState =
  | "not_connected"
  | "authorization_required"
  | "connected"
  | "reauthorization_required"
  | "disabled";

export interface SocialAccountDescriptor {
  providerAccountId: string;
  displayName: string;
  username?: string;
  platform: SocialPlatform;
}

/**
 * Provider adapter boundary. Implementations must validate scopes and account
 * eligibility, and must never publish without a valid human approval reference.
 */
export interface SocialProviderAdapter {
  readonly platform: SocialPlatform;
  getCapabilities(accountId: string): Promise<ProviderCapability[]>;
  listAuthorizedAccounts(): Promise<SocialAccountDescriptor[]>;
}

export interface PublishCommand {
  organizationId: string;
  socialAccountId: string;
  contentVersionId: string;
  approvalId: string;
  idempotencyKey: string;
  scheduledFor: string;
}

// Deliberately no publish() method exists in the initial foundation.
// Publishing is added only after approval-state, token, and provider audits.
