/**
 * Tenant-bound context types for server-side application services.
 * Never construct this object from an untrusted browser-supplied organization ID.
 * The authenticated membership lookup will be implemented with the approved DB schema.
 */
export type OrganizationRole = "owner" | "administrator" | "editor" | "analyst" | "viewer";

export interface AuthorizedOrganizationContext {
  organizationId: string;
  userId: string;
  role: OrganizationRole;
  membershipId: string;
}

export function assertOrganizationContext(
  context: AuthorizedOrganizationContext | null | undefined,
): asserts context is AuthorizedOrganizationContext {
  if (!context?.organizationId || !context.userId || !context.membershipId) {
    throw new Error("An authenticated organization membership is required.");
  }
}
