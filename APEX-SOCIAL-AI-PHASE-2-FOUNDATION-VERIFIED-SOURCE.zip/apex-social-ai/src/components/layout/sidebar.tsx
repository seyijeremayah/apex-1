import Link from "next/link";
import type { LucideIcon } from "lucide-react";
import {
  BarChart3, CalendarDays, CheckCheck, ChevronDown, CircleHelp,
  Command, Gauge, Layers3, Settings2, Sparkles, Users2, WandSparkles,
} from "lucide-react";

const primary = [
  { label: "Overview", href: "/dashboard", icon: Gauge },
  { label: "AI Content Studio", href: "/content", icon: WandSparkles },
  { label: "Publishing calendar", href: "/calendar", icon: CalendarDays },
  { label: "Approval queue", href: "/approvals", icon: CheckCheck, count: "4" },
];
const operations = [
  { label: "Social accounts", href: "/integrations", icon: Layers3 },
  { label: "Analytics & insights", href: "/analytics", icon: BarChart3 },
  { label: "Team & workspace", href: "/settings", icon: Users2 },
];

type NavItem = { label: string; href: string; icon: LucideIcon; count?: string };

function NavSection({ title, items }: { title: string; items: NavItem[] }) {
  return (
    <div className="mb-7">
      <p className="mb-2 px-3 text-[10px] font-semibold uppercase tracking-[0.2em] text-[#666d78]">{title}</p>
      <nav className="space-y-1">
        {items.map(({ label, href, icon: Icon, ...rest }) => (
          <Link key={href} href={href} className={`group flex items-center gap-3 rounded-xl px-3 py-2.5 text-[13px] transition ${href === "/dashboard" ? "border border-[#d4af37]/20 bg-[#d4af37]/[0.09] text-[#f2d978]" : "text-[#a0a5ae] hover:bg-white/[0.045] hover:text-white"}`}>
            <Icon size={16} strokeWidth={1.7} className="shrink-0" />
            <span className="flex-1">{label}</span>
            {"count" in rest && <span className="rounded-md bg-[#d4af37]/15 px-1.5 py-0.5 text-[10px] text-[#e6c85d]">{rest.count}</span>}
          </Link>
        ))}
      </nav>
    </div>
  );
}

export function Sidebar() {
  return (
    <aside className="fixed inset-y-0 left-0 z-30 hidden w-[252px] flex-col border-r border-white/[0.07] bg-[#0b0d10]/95 px-4 py-5 backdrop-blur-xl lg:flex">
      <Link href="/dashboard" className="mb-9 flex items-center gap-3 px-2">
        <div className="flex size-9 items-center justify-center rounded-xl border border-[#d4af37]/40 bg-[#d4af37]/10 text-[#e7c95f]"><Command size={19} /></div>
        <div><div className="text-[14px] font-semibold tracking-[0.19em] text-white">APEX</div><div className="text-[9px] tracking-[0.28em] text-[#b69b4b]">SOCIAL AI</div></div>
      </Link>

      <button className="mb-8 flex w-full items-center gap-3 rounded-xl border border-white/[0.08] bg-white/[0.025] p-3 text-left">
        <div className="flex size-8 items-center justify-center rounded-lg bg-gradient-to-br from-[#d4af37] to-[#7e6420] text-[11px] font-bold text-black">A</div>
        <div className="min-w-0 flex-1"><p className="truncate text-xs font-medium text-white">Acme Creative Co.</p><p className="mt-0.5 text-[10px] text-[#777e89]">Workspace</p></div>
        <ChevronDown size={14} className="text-[#777e89]" />
      </button>

      <NavSection title="Workspace" items={primary} />
      <NavSection title="Manage" items={operations} />

      <div className="mt-auto space-y-2">
        <div className="rounded-xl border border-[#d4af37]/15 bg-gradient-to-br from-[#d4af37]/[0.09] to-transparent p-3.5">
          <div className="mb-2 flex items-center gap-2 text-[#e5c75c]"><Sparkles size={14} /><span className="text-[11px] font-semibold">APEX Intelligence</span></div>
          <p className="text-[11px] leading-5 text-[#969ba4]">Your brand brain is ready to learn. Add your voice, offers and audience.</p>
          <Link href="/settings" className="mt-3 inline-flex text-[10px] font-semibold text-[#e5c75c]">Configure brand <span className="ml-1">↗</span></Link>
        </div>
        <Link href="/settings" className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-[12px] text-[#9298a2] hover:bg-white/[0.04]"><Settings2 size={16} /> Settings</Link>
        <a href="mailto:support@apexsocial.ai" className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-[12px] text-[#9298a2] hover:bg-white/[0.04]"><CircleHelp size={16} /> Help & support</a>
      </div>
    </aside>
  );
}
