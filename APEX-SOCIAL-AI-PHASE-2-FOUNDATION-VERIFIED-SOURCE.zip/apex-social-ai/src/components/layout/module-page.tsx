import type { LucideIcon } from "lucide-react";
import { ArrowUpRight, LockKeyhole } from "lucide-react";
import { Panel } from "@/components/ui/panel";

export function ModulePage({
  eyebrow,
  title,
  description,
  icon: Icon,
  features,
}: {
  eyebrow: string;
  title: string;
  description: string;
  icon: LucideIcon;
  features: string[];
}) {
  return (
    <div className="mx-auto max-w-5xl space-y-7">
      <div className="flex items-start gap-4"><div className="flex size-12 shrink-0 items-center justify-center rounded-2xl border border-[#d4af37]/20 bg-[#d4af37]/[0.08] text-[#e3c45b]"><Icon size={21} /></div><div><p className="text-[10px] uppercase tracking-[0.2em] text-[#b99d49]">{eyebrow}</p><h2 className="mt-2 text-2xl font-semibold tracking-tight text-white">{title}</h2><p className="mt-2 max-w-2xl text-sm leading-6 text-[#858b96]">{description}</p></div></div>
      <Panel className="overflow-hidden">
        <div className="flex items-center gap-3 border-b border-white/[0.07] px-5 py-4"><LockKeyhole size={15} className="text-[#d4af37]" /><div><p className="text-xs font-medium text-white">Foundation ready · Feature not activated</p><p className="mt-0.5 text-[10px] text-[#777e89]">This area is scaffolded for the next approved build steps.</p></div></div>
        <div className="grid gap-3 p-5 md:grid-cols-2">{features.map((feature) => <div key={feature} className="flex items-center gap-3 rounded-xl border border-white/[0.06] bg-white/[0.02] p-3"><span className="size-1.5 rounded-full bg-[#d4af37]" /><span className="text-xs text-[#b6bbc3]">{feature}</span></div>)}</div>
      </Panel>
      <div className="flex items-center gap-2 text-[10px] text-[#686f79]"><ArrowUpRight size={12} /> No external accounts, data or publishing actions are connected in this foundation build.</div>
    </div>
  );
}
