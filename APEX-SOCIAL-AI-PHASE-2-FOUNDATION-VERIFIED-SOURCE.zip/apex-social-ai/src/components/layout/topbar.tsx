import { Bell, Search, Command, ChevronDown } from "lucide-react";

export function Topbar({ title }: { title: string }) {
  return (
    <header className="sticky top-0 z-20 flex h-[76px] items-center justify-between border-b border-white/[0.07] bg-[#08090b]/80 px-5 backdrop-blur-xl md:px-8">
      <div><p className="text-[10px] uppercase tracking-[0.19em] text-[#777e89]">Workspace / APEX</p><h1 className="mt-1 text-lg font-semibold tracking-tight text-white">{title}</h1></div>
      <div className="flex items-center gap-3">
        <button aria-label="Search" className="hidden h-9 items-center gap-2 rounded-lg border border-white/[0.08] bg-white/[0.025] px-3 text-xs text-[#858b96] sm:flex"><Search size={14} /> Search anything <span className="ml-4 flex items-center gap-1 rounded border border-white/10 px-1.5 py-0.5 text-[9px]"><Command size={9} /> K</span></button>
        <button aria-label="Notifications" className="relative flex size-9 items-center justify-center rounded-lg border border-white/[0.08] text-[#a1a6af]"><Bell size={16} /><span className="absolute right-2 top-2 size-1.5 rounded-full bg-[#d4af37]" /></button>
        <div className="ml-1 flex items-center gap-2 border-l border-white/[0.08] pl-3"><div className="flex size-8 items-center justify-center rounded-full border border-[#d4af37]/30 bg-[#d4af37]/10 text-[10px] font-semibold text-[#e5c75c]">JD</div><div className="hidden sm:block"><p className="text-[11px] font-medium text-white">Jordan Davis</p><p className="text-[9px] text-[#777e89]">Workspace owner</p></div><ChevronDown size={13} className="text-[#777e89]" /></div>
      </div>
    </header>
  );
}
