import { BarChart3 } from "lucide-react";
import { ModulePage } from "@/components/layout/module-page";
export default function AnalyticsPage() { return <ModulePage eyebrow="Measure & learn" title="Analytics & insights" description="Understand content performance, audience response and campaign outcomes across connected channels." icon={BarChart3} features={["Cross-channel performance overview", "Reach, impressions and engagement", "Content-level performance", "Audience and trend insights", "Campaign reporting", "Exportable performance summaries"]} />; }
