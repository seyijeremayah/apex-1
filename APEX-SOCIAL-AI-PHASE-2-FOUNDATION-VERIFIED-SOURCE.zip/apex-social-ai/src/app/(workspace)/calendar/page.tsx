import { CalendarDays } from "lucide-react";
import { ModulePage } from "@/components/layout/module-page";
export default function CalendarPage() { return <ModulePage eyebrow="Plan & schedule" title="Publishing calendar" description="Coordinate approved content across Instagram, Facebook and TikTok with a clear view of every planned post." icon={CalendarDays} features={["Unified publishing calendar", "Platform-specific schedule slots", "Draft and scheduled content views", "Timezone-aware scheduling", "Publishing job status and retries", "Approval status visibility"]} />; }
