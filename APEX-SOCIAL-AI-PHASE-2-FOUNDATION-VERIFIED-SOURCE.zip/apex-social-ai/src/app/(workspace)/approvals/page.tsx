import { ShieldCheck } from "lucide-react";
import { ModulePage } from "@/components/layout/module-page";
export default function ApprovalsPage() { return <ModulePage eyebrow="Human in control" title="Approval queue" description="Every public post must be reviewed and approved by an authorized human. Edits invalidate earlier approval." icon={ShieldCheck} features={["Review content and media versions", "Approve or request changes", "Approval tied to exact content hash", "Authorized approver and timestamp", "Immutable audit history", "Execution-time approval revalidation"]} />; }
