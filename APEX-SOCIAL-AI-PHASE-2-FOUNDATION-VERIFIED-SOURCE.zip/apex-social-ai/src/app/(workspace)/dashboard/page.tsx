import Link from "next/link";
import {
  ArrowUpRight, ArrowUpRight as ArrowUp, Clock3, Instagram, Facebook, Music2, Plus, Sparkles,
  TrendingUp, WandSparkles,
} from "lucide-react";
import { Panel } from "@/components/ui/panel";

const metrics = [
  { label: "Total reach", value: "128.4K", change: "+18.6%", up: true, note: "vs. previous 30 days" },
  { label: "Engagement rate", value: "6.82%", change: "+1.2%", up: true, note: "vs. previous 30 days" },
  { label: "Content published", value: "24", change: "+4", up: true, note: "vs. previous 30 days" },
  { label: "Pending approvals", value: "04", change: "Needs review", up: false, note: "Human approval required" },
];

const activities = [
  { title: "Summer collection launch", platform: "Instagram", status: "Awaiting approval", time: "Today · 10:30 AM", color: "text-pink-300" },
  { title: "Behind the scenes: studio day", platform: "Facebook", status: "Scheduled", time: "Today · 2:00 PM", color: "text-blue-300" },
  { title: "3 ways to style the essentials", platform: "TikTok", status: "Draft", time: "Tomorrow · 9:00 AM", color: "text-white" },
];

function MetricCard({ item, index }: { item: (typeof metrics)[number]; index: number }) {
  const Icon = index === 3 ? Clock3 : TrendingUp;
  return (
    <Panel className="p-5 transition hover:border-white/[0.14]">
      <div className="flex items-center justify-between"><p className="text-[11px] text-[#858b96]">{item.label}</p><Icon size={15} className="text-[#777e89]" /></div>
      <div className="mt-4 flex items-end justify-between gap-2"><p className="text-[28px] font-semibold tracking-tight text-white">{item.value}</p><span className={`mb-1 inline-flex items-center gap-1 text-[10px] ${index === 3 ? "text-[#e6c85d]" : "text-emerald-400"}`}>{index === 3 ? <Clock3 size={11} /> : <ArrowUpRight size={11} />}{item.change}</span></div>
      <p className="mt-1 text-[10px] text-[#656c77]">{item.note}</p>
    </Panel>
  );
}

export default function DashboardPage() {
  return (
    <div className="space-y-7">
      <section className="flex flex-col justify-between gap-5 md:flex-row md:items-end">
        <div><div className="mb-2 inline-flex items-center gap-2 rounded-full border border-[#d4af37]/20 bg-[#d4af37]/[0.07] px-2.5 py-1 text-[9px] font-medium uppercase tracking-[0.16em] text-[#e1c45d]"><Sparkles size={11} /> Your marketing command centre</div><h2 className="text-2xl font-semibold tracking-tight text-white md:text-[30px]">Good morning, Jordan<span className="text-[#d4af37]">.</span></h2><p className="mt-2 text-sm text-[#858b96]">Here’s what’s happening across your social channels.</p></div>
        <Link href="/content" className="inline-flex h-10 items-center justify-center gap-2 rounded-xl bg-[#d4af37] px-4 text-xs font-semibold text-[#17130a] shadow-[0_8px_30px_rgba(212,175,55,0.12)] transition hover:bg-[#e2c454]"><Plus size={15} /> Create content</Link>
      </section>

      <section className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">{metrics.map((item, index) => <MetricCard key={item.label} item={item} index={index} />)}</section>

      <section className="grid gap-5 xl:grid-cols-[1.55fr_1fr]">
        <Panel className="overflow-hidden">
          <div className="flex items-center justify-between border-b border-white/[0.07] px-5 py-4"><div><h3 className="text-sm font-semibold text-white">Performance overview</h3><p className="mt-1 text-[10px] text-[#777e89]">Audience reach across connected channels</p></div><button className="rounded-lg border border-white/[0.09] px-3 py-1.5 text-[10px] text-[#a0a5ae]">Last 30 days</button></div>
          <div className="px-5 pb-5 pt-6"><div className="flex items-end gap-2"><span className="text-3xl font-semibold tracking-tight text-white">128,420</span><span className="mb-1 inline-flex items-center gap-1 text-[10px] text-emerald-400"><ArrowUpRight size={11} /> 18.6%</span></div><p className="mt-1 text-[10px] text-[#777e89]">Total impressions and reach · Demo data</p>
            <div className="mt-7 flex h-[170px] items-end gap-2 border-b border-white/[0.08] pb-0">
              {[34,48,42,60,52,69,58,77,66,85,73,92,80,100,86,95,75,88,68,82,92,78,100,90,110,96,120,104].map((height, i) => <div key={i} className="group relative flex-1 rounded-t-[3px] bg-gradient-to-t from-[#8b7026]/40 to-[#e0c45f]/90 opacity-80 transition hover:opacity-100" style={{ height: `${height}%` }} />)}
            </div><div className="mt-3 flex justify-between text-[9px] text-[#666d78]"><span>OCT 20</span><span>OCT 27</span><span>NOV 03</span><span>NOV 10</span><span>NOV 19</span></div>
          </div>
        </Panel>

        <Panel className="p-5">
          <div className="flex items-center justify-between"><div><h3 className="text-sm font-semibold text-white">Channel health</h3><p className="mt-1 text-[10px] text-[#777e89]">Connection status overview</p></div><Link href="/integrations" className="text-[10px] text-[#d9bd59]">Manage all ↗</Link></div>
          <div className="mt-5 space-y-3">
            {[{ name: "Instagram", detail: "Business account", Icon: Instagram, tone: "text-pink-300" }, { name: "Facebook", detail: "Page connection", Icon: Facebook, tone: "text-blue-300" }, { name: "TikTok", detail: "Creator account", Icon: Music2, tone: "text-white" }].map(({ name, detail, Icon, tone }) => <div key={name} className="flex items-center gap-3 rounded-xl border border-white/[0.07] bg-white/[0.02] p-3"><div className={`flex size-9 items-center justify-center rounded-lg bg-white/[0.05] ${tone}`}><Icon size={17} /></div><div className="flex-1"><p className="text-xs font-medium text-white">{name}</p><p className="mt-0.5 text-[9px] text-[#777e89]">{detail}</p></div><span className="inline-flex items-center gap-1.5 text-[9px] text-[#a4a9b2]"><span className="size-1.5 rounded-full bg-[#d4af37]" /> Setup pending</span></div>)}
          </div>
          <div className="mt-4 rounded-xl border border-dashed border-white/[0.12] p-3 text-center"><p className="text-[10px] text-[#858b96]">Connect accounts to unlock publishing and insights.</p><Link href="/integrations" className="mt-2 inline-flex items-center gap-1 text-[10px] font-medium text-[#e0c45f]">Open connection centre <ArrowUp size={10} /></Link></div>
        </Panel>
      </section>

      <section className="grid gap-5 xl:grid-cols-[1.35fr_1fr]">
        <Panel className="p-5"><div className="mb-4 flex items-center justify-between"><div><h3 className="text-sm font-semibold text-white">Upcoming content</h3><p className="mt-1 text-[10px] text-[#777e89]">Your next posts across platforms</p></div><Link href="/calendar" className="text-[10px] text-[#d9bd59]">View calendar ↗</Link></div><div className="space-y-2">{activities.map((item) => <div key={item.title} className="flex flex-col gap-2 rounded-xl border border-white/[0.06] bg-white/[0.018] p-3 sm:flex-row sm:items-center"><div className="flex-1"><p className="text-xs font-medium text-white">{item.title}</p><p className={`mt-1 text-[9px] ${item.color}`}>{item.platform}<span className="mx-1.5 text-[#555b64]">•</span><span className="text-[#777e89]">{item.time}</span></p></div><span className="w-fit rounded-md border border-white/[0.08] px-2 py-1 text-[9px] text-[#a0a5ae]">{item.status}</span></div>)}</div></Panel>
        <Panel className="relative overflow-hidden p-5"><div className="absolute -right-12 -top-12 size-44 rounded-full bg-[#d4af37]/[0.07] blur-3xl" /><div className="relative"><div className="mb-3 flex size-9 items-center justify-center rounded-xl border border-[#d4af37]/20 bg-[#d4af37]/10 text-[#e5c75c]"><WandSparkles size={17} /></div><h3 className="text-sm font-semibold text-white">Meet your AI marketing team</h3><p className="mt-2 max-w-sm text-[11px] leading-5 text-[#8b919b]">Build a consistent brand voice, turn ideas into platform-ready content, and keep every public post under human control.</p><Link href="/content" className="mt-5 inline-flex items-center gap-2 rounded-lg border border-[#d4af37]/30 bg-[#d4af37]/10 px-3 py-2 text-[10px] font-medium text-[#e5c75c]">Explore content studio <ArrowUpRight size={12} /></Link></div></Panel>
      </section>
      <p className="text-center text-[9px] tracking-wide text-[#535963]">DEMO WORKSPACE · SAMPLE METRICS AND ACTIVITY · NO SOCIAL ACCOUNTS CONNECTED</p>
    </div>
  );
}
