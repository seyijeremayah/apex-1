import { FileText } from "lucide-react";
import { ModulePage } from "@/components/layout/module-page";
export default function ContentPage() { return <ModulePage eyebrow="Create & collaborate" title="AI Content Studio" description="A single workspace for planning, drafting and refining on-brand content for every priority channel." icon={FileText} features={["Brand-aware content briefs", "Captions, scripts and post concepts", "Platform-specific content variants", "Media library and asset versions", "Draft history and collaboration", "AI provider selection (BYOK)"]} />; }
