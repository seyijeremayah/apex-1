import Link from "next/link";
export default function AuthErrorPage() {
  return <main className="flex min-h-screen items-center justify-center p-6"><div className="max-w-md rounded-2xl border border-white/10 bg-[#101216] p-8 text-center"><p className="text-xs uppercase tracking-[0.2em] text-[#d4af37]">APEX SOCIAL AI</p><h1 className="mt-4 text-xl font-semibold text-white">Sign-in could not be completed</h1><p className="mt-2 text-sm leading-6 text-[#858b96]">Please return to the application and try again. If this continues, check the Supabase Auth redirect URL configuration.</p><Link href="/dashboard" className="mt-6 inline-flex rounded-lg bg-[#d4af37] px-4 py-2 text-xs font-semibold text-black">Return to workspace</Link></div></main>;
}
