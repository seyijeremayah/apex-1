import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: { default: "APEX SOCIAL AI", template: "%s | APEX SOCIAL AI" },
  description: "Your AI-powered social media operations workspace.",
  applicationName: "APEX SOCIAL AI",
};

export const viewport: Viewport = {
  themeColor: "#08090b",
  colorScheme: "dark",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
