# ADR-002: Initial Social Platform Priorities

- **Status:** Accepted
- **Date:** 2026-11-19
- **Decision:** Instagram first, Facebook second, TikTok third.
- **Context:** The product's initial social integrations should be delivered in a deliberate priority order, with platform eligibility, scopes, app review and API limits validated before enabling features.
- **Approval:** Explicit user approval in the APEX SOCIAL AI Phase 1 planning conversation.
- **Implementation status:** Provider interfaces and UI placeholders created; no live integration exists.
