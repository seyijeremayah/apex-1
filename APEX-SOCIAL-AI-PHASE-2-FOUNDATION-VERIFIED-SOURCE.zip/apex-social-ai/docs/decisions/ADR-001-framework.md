# ADR-001: Application Framework

- **Status:** Accepted
- **Date:** 2026-11-19
- **Decision:** Next.js 16 App Router with TypeScript.
- **Context:** The application requires a modern full-stack React framework compatible with the approved Vercel hosting target.
- **Approval:** Explicit user approval in the APEX SOCIAL AI Phase 1 planning conversation.
- **Implementation status:** Foundation scaffold created locally.
