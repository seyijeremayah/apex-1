# Initial Security Boundaries

1. Authentication tokens are cookie-managed through `@supabase/ssr`.
2. Server-side identity checks must use verified claims; never trust raw cookie contents or user-editable metadata for authorization.
3. Organization membership must be resolved from server-side database state before any tenant data access.
4. Every tenant-owned table in exposed schemas must have RLS enabled, least-privilege grants and operation-specific policies.
5. Storage paths and policies must enforce organization membership.
6. Customer BYOK credentials must be encrypted using authenticated encryption with a managed key hierarchy before production use. Key management is not implemented in this phase.
7. Secrets must not appear in browser bundles, logs, traces, URLs, analytics or error messages.
8. Public publishing must require a human approval bound to exact content/media hashes, platform, account and schedule; changes invalidate approval.
9. Provider calls must be idempotent and reconciled after ambiguous timeouts.
10. This foundation is not yet approved for production customer data or public publishing.
