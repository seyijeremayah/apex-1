# Phase 2 — Application Foundation

**Status:** Implemented locally; dependency installation/build verification pending.

## Scope

Create the Next.js 16 application foundation and project files from the approved Phase 1 architecture. This phase does not implement business workflows or connect live social providers.

## Architecture

- Next.js 16 App Router with TypeScript strict mode.
- Tailwind CSS v4 with shadcn/ui-compatible configuration and reusable primitives.
- Supabase SSR client split into browser and server factories.
- Next.js 16 `proxy.ts` session refresh using `auth.getClaims()`.
- Modular-monolith feature folders under `src/modules`.
- Provider adapter contracts separate from application modules.

## Security boundaries

- Supabase public URL/publishable key only in `NEXT_PUBLIC_*` variables.
- No service-role key or customer BYOK secrets in client-visible configuration.
- Organization context is a server-side authorization result, not a browser-supplied tenant selector.
- The scaffold has no publishing method; future publishing requires an approved, immutable approval record and execution-time revalidation.
- No tenant data is persisted yet; migrations and RLS are intentionally deferred until the database design is implemented and audited.

## Verification status

- Source files and project structure created.
- Node.js runtime inspected: v22.16.0.
- `create-next-app` network scaffold attempt timed out in this environment.
- No dependency install, ESLint, TypeScript check or Next.js build has completed yet. Do not treat this project as build-verified until those checks run successfully in a network-enabled environment.

## Out of scope

GitHub push, Supabase project mutation, provider OAuth registration, live social connections, paid services, Vercel deployment and production publishing.
