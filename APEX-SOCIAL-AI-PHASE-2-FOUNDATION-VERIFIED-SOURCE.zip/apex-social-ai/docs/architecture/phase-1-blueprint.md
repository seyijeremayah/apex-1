# APEX SOCIAL AI — Phase 1 Architecture Blueprint

**Document status:** Phase 1 planning — in progress  
**Operating mode:** PLAN / ARCHITECT  
**Implementation status:** Not started  
**Deployment status:** Not deployed  
**Engineering standard:** APEX ENGINEERING (`apex-engineering/SKILL.md`)  
**Last updated:** 19 November 2026

---

## 1. Approved product decisions

The following decisions were explicitly approved by the product owner and are recorded as accepted.

### ADR-001 — Application framework

- **Status:** Accepted
- **Decision:** Use Next.js 16.
- **Context:** The original proposal specified Next.js 14. The product owner approved moving to Next.js 16 for this new application.
- **Rationale:** Next.js 16 is listed as Active LTS in the official support policy; Next.js 14 is listed as unsupported.
- **Consequences:** The architecture and dependency plan must target Next.js 16-compatible versions. Before implementation, verify the current stable patch version, Node.js requirements, deployment compatibility, and relevant migration guidance.
- **Approval:** Explicitly approved by the product owner on 19 November 2026.

### ADR-002 — Initial social platform integration priorities

- **Status:** Accepted
- **Decision:** Prioritize integrations in this order:
  1. Instagram
  2. Facebook
  3. TikTok
- **Context:** The product owner selected these platforms for the first integration effort.
- **Consequences:** The provider-adapter architecture should support these three platforms first. This priority does not guarantee API access, app review, permission approval, or feature availability.
- **Approval:** Explicitly approved by the product owner on 19 November 2026.

### Previously approved product constraints

These remain fixed unless the product owner explicitly changes them:

- **API payment model:** BYOK — each company supplies and pays for its own provider credentials.
- **Publishing governance:** Human approval is required before public publishing.
- **Customer deployment model:** One centralized multi-tenant SaaS platform.
- **Backend:** Supabase.
- **Deployment target:** Vercel.
- **Notion:** Not used as the application database or backend.
- **External actions:** No GitHub push, public release, paid resource creation, or production deployment without separate explicit authorization.

---

## 2. Product objective

Build APEX SOCIAL AI as a multi-tenant AI-powered social media management SaaS that provides each customer company with an isolated marketing workspace, its own team and permissions, brand knowledge, provider credentials, social accounts, content, campaigns, analytics, and activity records.

The reference image, “The One-Person Social Media Team,” is product inspiration. The deliverable must be operational software, not merely a static visual imitation.

## 3. Proposed system architecture

Use a modular monolith initially, with explicit module boundaries and provider adapters. Avoid premature microservice decomposition.

### Logical layers

1. **Web application:** Next.js 16 App Router, TypeScript, Tailwind CSS, shadcn/ui.
2. **Application services:** server-side authorization, organization context, business rules, API orchestration, approval enforcement.
3. **Domain modules:** organizations, integrations, knowledge, AI orchestration, research, content, publishing, growth, analytics, automation, notifications, audit.
4. **Data and identity:** Supabase PostgreSQL, Supabase Auth, Row Level Security, Storage, Realtime where justified.
5. **Background processing:** evaluate Supabase Queues and Cron for durable jobs and scheduled dispatch; verify current product maturity, availability, limits, and plan requirements before committing.
6. **External providers:** customer-authorized AI, social, and productivity APIs.
7. **Operations:** Vercel hosting, secrets management/KMS, monitoring, backups, incident and recovery procedures.

### Architecture principles

- Tenant identity is established and verified server-side; never trust a company ID supplied only by the browser.
- RLS, database grants, and server-side authorization are layered controls.
- Customer credentials are encrypted and decrypted only in trusted server-side execution paths.
- AI output is untrusted input and cannot bypass authorization or approval.
- Every external side effect is authorized, logged, and made retry-safe.
- Provider capabilities are feature-gated by actual scopes, app review, account type, and API availability.

## 4. Proposed domain and database areas

Initial table groups to refine before implementation:

| Area | Candidate entities |
|---|---|
| Identity and tenancy | profiles, organizations, workspaces, memberships, roles |
| Integrations | provider_connections, encrypted_credentials, oauth_grants, provider_scopes |
| Brand knowledge | brand_profiles, brand_guidelines, products, faqs, knowledge_assets |
| Research | competitors, research_reports, keywords, trend_observations |
| Content | content_items, content_versions, media_assets |
| Social | social_accounts, account_permissions |
| Publishing | approval_records, publishing_jobs, publishing_attempts |
| Growth | campaigns, experiments, audience_segments |
| Analytics | analytics_snapshots, performance_reports |
| Automation | workflow_definitions, workflow_runs, notifications |
| Governance | audit_events, security_events, usage_records |

All tenant-owned records must carry a validated organization relationship. The final schema must specify foreign keys, unique constraints, indexes, deletion behavior, retention, and RLS/grant policy for every exposed table.

## 5. Multi-tenant authorization model

- Organizations own company data and integrations.
- Memberships connect users to organizations.
- Roles are scoped to an organization, not globally trusted from client input.
- Every read and write is checked against the authenticated user’s active membership and required permission.
- RLS policies must cover SELECT, INSERT, UPDATE, and DELETE as applicable.
- Storage objects must use tenant-aware paths and matching authorization policies.
- Background jobs must carry a trusted organization context and re-check authorization at execution time.
- Automated negative tests must attempt cross-tenant access through database, storage, and server endpoints.

Proposed roles for further requirements validation: owner, administrator, editor, analyst, and viewer. Final permissions remain to be specified.

## 6. BYOK credential architecture

- Accept customer credentials only through authenticated HTTPS server routes.
- Validate organization membership and integration-management permission before accepting or changing credentials.
- Encrypt credentials using authenticated encryption, with envelope encryption and a managed KMS or equivalent production key-management service as the preferred design.
- Store ciphertext, nonce/IV, authentication tag, key version, provider metadata, and minimal masked display metadata; never store plaintext credentials.
- Keep master/key-encryption keys outside the database and outside public frontend environment variables.
- Decrypt only inside a trusted server-side provider adapter for a specific authorized task.
- Never return plaintext credentials after initial submission.
- Exclude secrets from logs, traces, analytics, URLs, error messages, and client bundles.
- Define rotation, revocation, access audit, and recovery procedures.
- Separate customer BYOK credentials from platform infrastructure secrets.

The exact cryptographic library, KMS, key lifecycle, and operational recovery design remain to be selected during detailed security design.

## 7. Human approval and publishing

Public publishing requires explicit human approval.

The approval record must bind to:
- Organization and authorized approver.
- Content version or canonical content hash.
- Media references and media version/hash.
- Target platform and social account.
- Publishing action and relevant metadata.
- Intended schedule or execution window.

Before execution, the publishing worker must re-check organization authorization, account authorization, approval validity, and content integrity. Any material edit invalidates approval and requires re-approval.

Use idempotency keys, attempt records, bounded retries, and reconciliation for uncertain provider responses. Never assume a timed-out request failed; check provider state where possible before retrying to avoid duplicate posts.

## 8. Initial social integration plan

### Instagram — priority 1

Investigate supported Instagram API products and authentication options, account eligibility, publishing formats, permissions, review requirements, messaging/comment scopes, quotas, and current Meta developer requirements. Do not assume every Instagram account type or feature is supported.

### Facebook — priority 2

Prioritize Facebook Pages rather than assuming unrestricted personal-profile publishing. Validate Page roles/tasks, Page access tokens, required permissions, app review, supported post types, and moderation capabilities.

### TikTok — priority 3

Investigate Content Posting API, creator authorization, required scopes, media transfer requirements, audit requirements, privacy restrictions, and posting caps. TikTok documentation states that unaudited clients are restricted to private viewing for Direct Post; public posting requires the relevant audit. This is a material launch dependency.

Each integration must have a capability matrix and status: researched, credentials/configuration required, development-ready, implemented, tested, provider-approved, or production-enabled.

## 9. Security threat areas

Threat model must cover at minimum:
- Cross-tenant data and storage leakage.
- Credential theft and misuse.
- Compromised user or administrator accounts.
- Privilege escalation and broken object-level authorization.
- Prompt injection and malicious content/attachments.
- Unauthorized or modified publishing after approval.
- OAuth token theft, replay, and improper scope handling.
- Webhook spoofing and replay.
- Queue/job tampering and duplicate execution.
- SSRF and unsafe URL/media ingestion.
- XSS, CSRF, injection, dependency compromise, and rate-limit abuse.
- Sensitive data exposure through logs, analytics, exports, or backups.
- Provider outages, quota exhaustion, and partial failures.

Security work must include severity, likelihood, impact, mitigations, residual risk, and test evidence. Do not claim certification or absolute protection.

## 10. Proposed project structure

```text
apex-social-ai/
├── src/
│   ├── app/
│   │   ├── (auth)/
│   │   ├── (dashboard)/
│   │   ├── onboarding/
│   │   └── api/
│   ├── modules/
│   │   ├── organizations/
│   │   ├── integrations/
│   │   ├── knowledge/
│   │   ├── ai-brain/
│   │   ├── research/
│   │   ├── content-studio/
│   │   ├── publishing/
│   │   ├── growth/
│   │   ├── analytics/
│   │   └── automation/
│   ├── components/
│   ├── lib/
│   │   ├── supabase/
│   │   ├── security/
│   │   ├── encryption/
│   │   └── permissions/
│   └── types/
├── supabase/
│   ├── migrations/
│   ├── functions/
│   └── tests/
├── tests/
│   ├── unit/
│   ├── integration/
│   ├── security/
│   └── e2e/
├── docs/
│   ├── architecture/
│   ├── security/
│   └── decisions/
└── README.md
```

This is a proposed structure, not a created repository.

## 11. Phase 1 remaining planning work

1. Complete discovery of target customers, user journeys, and company/team roles.
2. Define measurable MVP success criteria and launch scope.
3. Create a feature-by-feature provider capability matrix for Instagram, Facebook, and TikTok.
4. Research official Meta and TikTok app review, permission, and business eligibility requirements.
5. Complete detailed ERD and data dictionary.
6. Complete tenant role/permission matrix and RLS policy strategy.
7. Complete credential threat model, KMS options, and key lifecycle.
8. Specify approval state machine and publishing failure/reconciliation behavior.
9. Decide background-job architecture after checking Supabase Queues/Cron maturity, limits, and operational requirements.
10. Define environments, observability, backup/restore, incident response, and operational cost assumptions.
11. Define acceptance criteria and verification strategy for each planned phase.
12. Produce the final Phase 1 review package and request formal approval before implementation.

## 12. Open questions

These remain unresolved and must be clarified before finalizing the blueprint:

- Target customer segment and initial launch geography.
- Whether one user may belong to multiple companies and switch workspaces.
- Exact company role permissions and who may approve content.
- Whether platform administrators may access customer content, and under what audited support procedure.
- MVP publishing formats for each priority social platform.
- Whether content scheduling is required for all three platforms at initial launch.
- Data retention and account deletion requirements.
- Expected initial customer count and usage volume.
- Production KMS/secrets-management provider and budget.
- Whether a platform subscription/billing system is in scope for a later phase.

## 13. Phase 1 acceptance checklist

- [ ] Product problem, target users, and MVP scope are defined.
- [x] Next.js 16 decision recorded as accepted.
- [x] Initial integration priorities recorded as accepted: Instagram, Facebook, TikTok.
- [x] BYOK model recorded.
- [x] Mandatory human publishing approval recorded.
- [x] Centralized multi-tenant SaaS model recorded.
- [ ] Functional and non-functional requirements are complete.
- [ ] Detailed ERD and data dictionary are reviewed.
- [ ] Tenant role and permission matrix is complete.
- [ ] Security threat model and credential lifecycle are reviewed.
- [ ] Provider capability and app-review matrix is complete.
- [ ] Background job and operations design is justified.
- [ ] Risks, dependencies, assumptions, and acceptance tests are complete.
- [ ] Product owner formally approves the complete Phase 1 plan.

**Gate result:** Pending  
**Implementation authorization:** Not granted  
**Next action:** Continue Phase 1 planning only; present unresolved decisions and final approval package. No code implementation, repository creation, database migration, Git push, or deployment is authorized.
---

## Phase 1 approval record — 2026-11-19

**Status:** User-approved as the Phase 1 architecture and planning baseline.

The user approved the Phase 1 planning scope and its established foundational decisions, then explicitly authorized Phase 2 implementation. The accepted implementation scope is limited to creating the local Next.js 16 application foundation and project files described in `phase-2-foundation.md`.

The detailed items listed above as open questions remain engineering tasks to resolve before the corresponding data, security, provider, or production features are implemented. This approval does not represent that those details have already been designed, tested, or deployed, and does not authorize remote Git operations, live Supabase changes, external provider registration, paid services, or deployment.
